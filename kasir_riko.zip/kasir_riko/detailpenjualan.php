<?php
include "koneksi.php";

if (!isset($_GET['id'])) {
    die("ID Penjualan tidak ditemukan!");
}

$penjualanID = $_GET['id'];

// Ambil data penjualan
$penjualan = mysqli_query($conn, "SELECT penjualan.*, pelanggan.NamaPelanggan, pelanggan.Alamat, pelanggan.NomorTelepon
                                  FROM penjualan 
                                  JOIN pelanggan ON penjualan.PelangganID = pelanggan.PelangganID
                                  WHERE penjualan.PenjualanID = $penjualanID");
$data_penjualan = mysqli_fetch_assoc($penjualan);

// Ambil data detail penjualan
$detail = mysqli_query($conn, "SELECT detailpenjualan.*, produk.NamaProduk, produk.Harga 
                               FROM detailpenjualan 
                               JOIN produk ON detailpenjualan.ProdukID = produk.ProdukID
                               WHERE detailpenjualan.PenjualanID = $penjualanID");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Detail Penjualan</title>
    <style>
        /* Gaya Umum */
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #7b2ff7, #4a00e0);
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            height: 100vh;
            color: #fff;
        }

        .container {
            background: #fff;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.2);
            text-align: center;
            width: 90%;
            max-width: 900px;
            color: #333;
        }

        h2 {
            color: #4a00e0;
            margin-bottom: 15px;
        }

        .card {
            background: #fff;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            text-align: left;
        }

        .table {
            width: 100%;
            margin-top: 15px;
            border-collapse: collapse;
            border-radius: 10px;
            overflow: hidden;
        }

        th, td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
            text-align: center;
        }

        th {
            background: #4a00e0;
            color: #fff;
        }

        tr:nth-child(even) {
            background: #f8f8f8;
        }

        a {
            text-decoration: none;
            color: #ff5e62;
            font-weight: bold;
        }

        a:hover {
            text-decoration: underline;
        }

        button {
            padding: 12px;
            background: linear-gradient(135deg, #ff7eb3, #ff758c);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease-in-out;
        }

        button:hover {
            background: linear-gradient(135deg, #ff758c, #ff5e62);
            transform: scale(1.05);
        }
    </style>
</head>
<body>

    <div class="container">
        <h2>Detail Penjualan</h2>

        <!-- Informasi Penjualan -->
        <div class="card">
            <h5>Informasi Penjualan</h5>
            <p><strong>ID Penjualan:</strong> <?= $data_penjualan['PenjualanID'] ?></p>
            <p><strong>Tanggal:</strong> <?= $data_penjualan['TanggalPenjualan'] ?></p>
            <p><strong>Pelanggan:</strong> <?= $data_penjualan['NamaPelanggan'] ?></p>
            <p><strong>Alamat:</strong> <?= $data_penjualan['Alamat'] ?></p>
            <p><strong>Nomor Telepon:</strong> <?= $data_penjualan['NomorTelepon'] ?></p>
            <p><strong>Total Harga:</strong> Rp <?= number_format($data_penjualan['TotalHarga'], 2) ?></p>
        </div>

        <!-- Tabel Detail Penjualan -->
        <div class="card">
            <h5>Detail Produk</h5>
            <table class="table table-bordered table-hover">
                <thead class="table-secondary">
                    <tr>
                        <th>Nama Produk</th>
                        <th>Harga</th>
                        <th>Jumlah</th>
                        <th>Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($detail)) { ?>
                        <tr>
                            <td><?= $row['NamaProduk'] ?></td>
                            <td>Rp <?= number_format($row['Harga'], 2) ?></td>
                            <td><?= $row['JumlahProduk'] ?></td>
                            <td>Rp <?= number_format($row['Subtotal'], 2) ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>

        <a href="penjualan.php" class="btn btn-dark mt-3">Kembali ke Penjualan</a>
    </div>

</body>
</html>
