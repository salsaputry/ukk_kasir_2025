<?php
include "koneksi.php";

// Tambah Data Produk
if (isset($_POST['tambah'])) {
    $nama = $_POST['nama'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];

    $sql = "INSERT INTO produk (NamaProduk, Harga, Stok) VALUES ('$nama', '$harga', '$stok')";
    mysqli_query($conn, $sql);
    header("Location: produk.php");
}

// Ubah Data Produk
if (isset($_POST['ubah'])) {
    $id = $_POST['produkID'];
    $nama = $_POST['nama'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];

    $sql = "UPDATE produk SET NamaProduk = '$nama', Harga = '$harga', Stok = '$stok' WHERE ProdukID = $id";
    mysqli_query($conn, $sql);
    header("Location: produk.php");
}

// Hapus Data Produk
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($conn, "DELETE FROM produk WHERE ProdukID = $id");
    header("Location: produk.php");
}

// Ambil Semua Data Produk
$result = mysqli_query($conn, "SELECT * FROM produk");

// Ambil Data Produk untuk Ubah
if (isset($_GET['ubah_id'])) {
    $id = $_GET['ubah_id'];
    $produk = mysqli_query($conn, "SELECT * FROM produk WHERE ProdukID = $id");
    $data_produk = mysqli_fetch_assoc($produk);
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Data Produk</title>
    <style>
        /* Gaya Umum */
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #7b2ff7, #4a00e0);
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            height: 100vh;
            color: #fff;
        }

        .container {
            background: #fff;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.2);
            text-align: center;
            width: 90%;
            max-width: 600px;
            color: #333;
        }

        h2 {
            color: #4a00e0;
            margin-bottom: 15px;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        input {
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            width: 100%;
        }

        button {
            padding: 12px;
            background: linear-gradient(135deg, #ff7eb3, #ff758c);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease-in-out;
        }

        button:hover {
            background: linear-gradient(135deg, #ff758c, #ff5e62);
            transform: scale(1.05);
        }

        table {
            width: 100%;
            margin-top: 15px;
            border-collapse: collapse;
            border-radius: 10px;
            overflow: hidden;
        }

        th, td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
            text-align: center;
        }

        th {
            background: #4a00e0;
            color: #fff;
        }

        tr:nth-child(even) {
            background: #f8f8f8;
        }

        a {
            text-decoration: none;
            color: #ff5e62;
            font-weight: bold;
        }

        a:hover {
            text-decoration: underline;
        }

        .btn-back {
            background-color: #4a00e0;
            color: white;
            padding: 10px 15px;
            text-decoration: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: bold;
            display: inline-block;
            margin-top: 20px;
        }

        .btn-back:hover {
            background-color: #7b2ff7;
        }

    </style>
</head>
<body>

    <div class="container">
        <h2>Data Produk</h2>

        <!-- Form Tambah Data Produk -->
        <form method="POST">
            <input type="text" name="nama" placeholder="Nama Produk" required>
            <input type="number" name="harga" placeholder="Harga" required>
            <input type="number" name="stok" placeholder="Stok" required>
            <button type="submit" name="tambah">Tambah Produk</button>
        </form>

        <h3 class="mt-4">Daftar Produk</h3>
        <table>
            <tr>
                <th>ID</th>
                <th>Nama Produk</th>
                <th>Harga</th>
                <th>Stok</th>
                <th>Aksi</th>
            </tr>
            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <td><?= $row['ProdukID'] ?></td>
                    <td><?= $row['NamaProduk'] ?></td>
                    <td>Rp <?= number_format($row['Harga'], 2) ?></td>
                    <td><?= $row['Stok'] ?></td>
                    <td>
                        <a href="produk.php?ubah_id=<?= $row['ProdukID'] ?>" class="btn btn-success btn-sm">Ubah</a>
                        <a href="produk.php?hapus=<?= $row['ProdukID'] ?>" class="btn btn-danger btn-sm"
                           onclick="return confirm('Yakin ingin menghapus produk ini?')">Hapus</a>
                    </td>
                </tr>
            <?php } ?>
        </table>

        <!-- Form Ubah Data Produk (Jika Mengedit Produk) -->
        <?php if (isset($_GET['ubah_id'])) { ?>
            <h3>Edit Produk</h3>
            <form method="POST">
                <input type="hidden" name="produkID" value="<?= $data_produk['ProdukID'] ?>">
                <input type="text" name="nama" value="<?= $data_produk['NamaProduk'] ?>" required>
                <input type="number" name="harga" value="<?= $data_produk['Harga'] ?>" required>
                <input type="number" name="stok" value="<?= $data_produk['Stok'] ?>" required>
                <button type="submit" name="ubah">Ubah Produk</button>
            </form>
        <?php } ?>

        <!-- Tombol Kembali ke Beranda -->
        <a href="index.php" class="btn-back">Kembali ke Beranda</a>

    </div>

</body>
</html>
