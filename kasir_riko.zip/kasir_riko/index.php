<?php include "koneksi.php"; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Kasir</title>
    <style>
        /* Gaya Umum */
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #00bcd4, #9c27b0); /* Teal to purple gradient */
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background: #ffffff; /* Clean white background */
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.1); /* Light shadow for depth */
            text-align: center;
            width: 380px;
        }

        h1 {
            color: #9c27b0; /* Purple color for heading */
            font-size: 24px;
            margin-bottom: 20px;
        }

        .menu {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        a {
            display: block;
            padding: 14px;
            background: linear-gradient(135deg, #00bcd4, #00acc1); /* Soft teal gradient for buttons */
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: bold;
            transition: all 0.3s ease-in-out;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1); /* Lighter shadow */
        }

        a:hover {
            background: linear-gradient(135deg, #00acc1, #00bcd4); /* Hover effect with reversed gradient */
            transform: scale(1.05);
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Dashboard Kasir</h1>
        <div class="menu">
            <a href="pelanggan.php">Data Pelanggan</a>
            <a href="produk.php">Data Produk</a>
            <a href="penjualan.php">Data Penjualan</a>
        </div>
    </div>

</body>
</html>
