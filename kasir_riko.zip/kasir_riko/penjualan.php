<?php
include "koneksi.php";

// Tambah Data Penjualan
if (isset($_POST['tambah'])) {
    $tanggal = $_POST['tanggal'];
    $pelangganID = $_POST['pelangganID'];
    $produkID = $_POST['produkID'];
    $jumlah = $_POST['jumlah'];

    // Ambil data produk
    $queryProduk = mysqli_query($conn, "SELECT Harga, Stok FROM produk WHERE ProdukID = '$produkID'");
    $dataProduk = mysqli_fetch_assoc($queryProduk);
    $harga = $dataProduk['Harga'];
    $stokTersedia = $dataProduk['Stok'];

    // Cek apakah stok cukup
    if ($stokTersedia < $jumlah) {
        echo "<script>alert('Stok tidak mencukupi!'); window.location='penjualan.php';</script>";
        exit;
    }

    // Hitung total harga
    $subtotal = $harga * $jumlah;

    // Simpan ke tabel penjualan
    $sqlPenjualan = "INSERT INTO penjualan (TanggalPenjualan, PelangganID, TotalHarga) 
                     VALUES ('$tanggal', '$pelangganID', '$subtotal')";
    mysqli_query($conn, $sqlPenjualan);

    // Ambil ID penjualan terakhir
    $penjualanID = mysqli_insert_id($conn);

    // Simpan detail penjualan
    $sqlDetail = "INSERT INTO detailpenjualan (PenjualanID, ProdukID, JumlahProduk, Subtotal) 
                  VALUES ('$penjualanID', '$produkID', '$jumlah', '$subtotal')";
    mysqli_query($conn, $sqlDetail);

    // Kurangi stok produk
    $stokBaru = $stokTersedia - $jumlah;
    mysqli_query($conn, "UPDATE produk SET Stok = '$stokBaru' WHERE ProdukID = '$produkID'");

    // Redirect setelah berhasil
    header("Location: penjualan.php");
}

// Hapus Data Penjualan
if (isset($_GET['hapus'])) {
    $penjualanID = $_GET['hapus'];

    // Ambil data detail penjualan
    $queryDetail = mysqli_query($conn, "SELECT ProdukID, JumlahProduk FROM detailpenjualan WHERE PenjualanID = '$penjualanID'");
    
    // Kembalikan stok produk
    while ($row = mysqli_fetch_assoc($queryDetail)) {
        $produkID = $row['ProdukID'];
        $jumlah = $row['JumlahProduk'];

        // Ambil stok produk saat ini
        $queryProduk = mysqli_query($conn, "SELECT Stok FROM produk WHERE ProdukID = '$produkID'");
        $stokProduk = mysqli_fetch_assoc($queryProduk)['Stok'];

        // Update stok kembali
        $stokBaru = $stokProduk + $jumlah;
        mysqli_query($conn, "UPDATE produk SET Stok = '$stokBaru' WHERE ProdukID = '$produkID'");
    }

    // Hapus detail penjualan
    mysqli_query($conn, "DELETE FROM detailpenjualan WHERE PenjualanID = '$penjualanID'");

    // Hapus dari tabel penjualan
    mysqli_query($conn, "DELETE FROM penjualan WHERE PenjualanID = '$penjualanID'");

    header("Location: penjualan.php");
}

// Ambil data penjualan dengan detail pelanggan
$result = mysqli_query($conn, "SELECT p.*, pel.NamaPelanggan, pel.Alamat, pel.NomorTelepon 
    FROM penjualan p 
    JOIN pelanggan pel ON p.PelangganID = pel.PelangganID");

$pelanggan = mysqli_query($conn, "SELECT * FROM pelanggan");
$produk = mysqli_query($conn, "SELECT * FROM produk");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Penjualan</title>
    <style>
        /* Styling Section */
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #7b2ff7, #4a00e0);
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            height: 100vh;
            color: #fff;
        }

        .container {
            background: #fff;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.2);
            text-align: center;
            width: 90%;
            max-width: 600px;
            color: #333;
        }

        h2 {
            color: #4a00e0;
            margin-bottom: 15px;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        input, select {
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            width: 100%;
        }

        button {
            padding: 12px;
            background: linear-gradient(135deg, #ff7eb3, #ff758c);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease-in-out;
        }

        button:hover {
            background: linear-gradient(135deg, #ff758c, #ff5e62);
            transform: scale(1.05);
        }

        table {
            width: 100%;
            margin-top: 15px;
            border-collapse: collapse;
            border-radius: 10px;
            overflow: hidden;
        }

        th, td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
            text-align: center;
        }

        th {
            background: #4a00e0;
            color: #fff;
        }

        tr:nth-child(even) {
            background: #f8f8f8;
        }

        .btn-back {
            background-color: #4a00e0;
            color: white;
            padding: 10px 15px;
            text-decoration: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: bold;
            display: inline-block;
            margin-top: 20px;
        }

        .btn-back:hover {
            background-color: #7b2ff7;
        }
    </style>
</head>
<body>

    <div class="container">
        <h2>Manajemen Penjualan</h2>

        <!-- Form Tambah Penjualan -->
        <form method="POST">
            <input type="date" name="tanggal" class="form-control" required>
            <select name="pelangganID" class="form-control">
                <?php while ($row = mysqli_fetch_assoc($pelanggan)) { ?>
                    <option value="<?= $row['PelangganID'] ?>"><?= $row['NamaPelanggan'] ?></option>
                <?php } ?>
            </select>
            <select name="produkID" class="form-control" id="produk">
                <?php while ($row = mysqli_fetch_assoc($produk)) { ?>
                    <option value="<?= $row['ProdukID'] ?>" data-harga="<?= $row['Harga'] ?>">
                        <?= $row['NamaProduk'] ?> - Rp <?= number_format($row['Harga'], 2) ?>
                    </option>
                <?php } ?>
            </select>
            <input type="number" name="jumlah" class="form-control" id="jumlah" required>
            <button type="submit" name="tambah">Tambah Penjualan</button>
        </form>

        <h3 class="mt-4">Daftar Penjualan</h3>
        <table>
            <tr>
                <th>ID</th>
                <th>Tanggal</th>
                <th>Pelanggan</th>
                <th>Total Harga</th>
                <th>Aksi</th>
            </tr>
            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <td><?= $row['PenjualanID'] ?></td>
                    <td><?= $row['TanggalPenjualan'] ?></td>
                    <td><?= $row['NamaPelanggan'] ?></td>
                    <td>Rp <?= number_format($row['TotalHarga'], 2) ?></td>
                    <td>
                        <a href="penjualan.php?hapus=<?= $row['PenjualanID'] ?>" class="btn btn-danger btn-sm"
                           onclick="return confirm('Yakin ingin menghapus penjualan ini?')">Hapus</a>
                    </td>
                </tr>
            <?php } ?>
        </table>

        <a href="index.php" class="btn-back">Kembali ke Beranda</a>
    </div>

</body>
</html>
