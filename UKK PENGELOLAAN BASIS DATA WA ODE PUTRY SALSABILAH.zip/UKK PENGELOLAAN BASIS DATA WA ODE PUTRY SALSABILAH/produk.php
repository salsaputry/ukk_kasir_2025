<?php
include "koneksi.php";

// Tambah Produk
if (isset($_POST['tambah'])) {
    $nama = $_POST['nama'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];

    $sql = "INSERT INTO produk (NamaProduk, Harga, Stok) VALUES ('$nama', '$harga', '$stok')";
    mysqli_query($conn, $sql);

    header("Location: produk.php");
    exit();
}

// Hapus produk
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    $delete_query = "DELETE FROM produk WHERE ProdukID = $id";
    if (mysqli_query($conn, $delete_query)) {
        header("Location: produk.php");
    } else {
        echo "<script>alert('Data tidak dapat dihapus karena memiliki keterkaitan dengan data lain!'); window.location='produk.php';</script>";
    }
}

// Ambil data produk
$result = mysqli_query($conn, "SELECT * FROM produk");

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Produk</title>

    <style>
    body {
        font-family: Arial, sans-serif;
        background:rgb(254, 203, 211);
        margin: 20px;
        padding: 0;
    }

    .back-home {
        margin-top: 20px;
        text-align: left;
    }

    .back-home a {
        background: #ff758c;
        color: white;
        padding: 10px 15px;
        text-decoration: none;
        border-radius: 5px;
        font-size: 16px;
    }

    .back-home a:hover {
        background:rgb(255, 87, 115);
    }

    h2 {
        text-align: center;
        color:rgb(51, 54, 59);
        font-weight: bold;
    }

    .container {
        max-width: 900px;
        margin: 20px auto;
        background: white;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
    }

    form {
        display: flex;
        flex-direction: column;
        gap: 10px;
    }

    input, button {
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }

    button {
        background-color: #ff758c;
        color: white;
        cursor: pointer;
        font-weight: bold;
    }

    button:hover {
        background-color: rgb(255, 87, 115);
    }

    table {
        width: 100%;
        border-collapse: collapse;
        background: white;
        margin-top: 20px;
    }

    th, td {
        border: 1px solid #ddd;
        padding: 10px;
        text-align: center;
    }

    th {
        background-color: #ff758c;
        color: white;
    }

    .hapus {
        background-color:rgb(255, 38, 0);
        color: white;
        padding: 5px 10px;
        border-radius: 5px;
        text-decoration: none;
    }

    .hapus:hover {
        background-color:rgb(211, 6, 6);
    }

    

    </style>

</head>
<body>
    <div class="back-home">
        <a href="index.php">🏡 Kembali ke Home</a>
    </div>

    <h2>DATA PRODUK</h2>

    <div class="container">
        <form method="POST">
            <input type="text" name="nama" placeholder="Nama Produk" required>
            <input type="number" name="harga" placeholder="Harga" required>
            <input type="number" name="stok" placeholder="Stok" required>
            <button type="submit" name="tambah">Tambah Produk</button>
        </form>

        <table>
            <tr>
                <th>ID</th>
                <th>Nama Produk</th>
                <th>Harga</th>
                <th>Stok</th>
                <th>Aksi</th>
            </tr>
            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <td><?= $row['ProdukID'] ?></td>
                    <td><?= $row['NamaProduk'] ?></td>
                    <td>Rp <?= number_format($row['Harga'], 2) ?></td>
                    <td><?= $row['Stok'] ?></td>
                    <td class="aksi">  
                        <a href="produk.php?hapus=<?= $row['ProdukID'] ?>" class="hapus" onclick="return confirm('Apakah Anda yakin ingin menghapus produk ini?')">Hapus</a>
                    </td>
                </tr>
            <?php } ?>
        </table>
    </div>
</body>
</html>