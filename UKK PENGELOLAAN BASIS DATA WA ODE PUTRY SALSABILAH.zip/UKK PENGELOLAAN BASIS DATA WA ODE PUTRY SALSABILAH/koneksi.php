<?php
$host = "localhost";
$user = "root";
$password = "";
$dbname = "ukk_pengelolaan_basis_data";

$conn = mysqli_connect($host, $user, $password, $dbname);

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
