<?php
include "koneksi.php";

// Tambah pelanggan
if (isset($_POST['tambah'])) {
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $telepon = $_POST['telepon'];
    $sql = "INSERT INTO pelanggan (NamaPelanggan, Alamat, NomorTelepon) VALUES ('$nama', '$alamat', '$telepon')";
    mysqli_query($conn, $sql);
    header("Location: pelanggan.php");
}

// Hapus pelanggan
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    $delete_query = "DELETE FROM pelanggan WHERE PelangganID = $id";
    if (mysqli_query($conn, $delete_query)) {
        header("Location: pelanggan.php");
    } else {
        echo "<script>alert('Data tidak dapat dihapus karena memiliki keterkaitan dengan data lain!'); window.location='pelanggan.php';</script>";
    }
}


// Ambil data pelanggan untuk edit
$edit_id = "";
$edit_nama = "";
$edit_alamat = "";
$edit_telepon = "";
if (isset($_GET['edit'])) {
    $edit_id = $_GET['edit'];
    $result_edit = mysqli_query($conn, "SELECT * FROM pelanggan WHERE PelangganID = $edit_id");
    $row_edit = mysqli_fetch_assoc($result_edit);
    $edit_nama = $row_edit['NamaPelanggan'];
    $edit_alamat = $row_edit['Alamat'];
    $edit_telepon = $row_edit['NomorTelepon'];
}

// Proses update pelanggan
if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $telepon = $_POST['telepon'];
    $sql = "UPDATE pelanggan SET NamaPelanggan='$nama', Alamat='$alamat', NomorTelepon='$telepon' WHERE PelangganID = $id";
    mysqli_query($conn, $sql);
    header("Location: pelanggan.php");
}

$result = mysqli_query($conn, "SELECT * FROM pelanggan");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Pelanggan</title>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
       <style>
    body {
        background:rgb(254, 203, 211);
        font-family: Arial, sans-serif;
    }
    .container {
        margin: 20px auto;
        max-width: 900px;
        background: white;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
    }
    h2 {
        text-align: center;
        color:rgb(48, 51, 57);
        font-weight: bold;
    }
    .back-home {
    margin-top: 20px;
    text-align: left;
    }

    .back-home a {
        background: #ff758c;
        color: white;
        padding: 10px 15px;
        text-decoration: none;
        border-radius: 5px;
        font-size: 16px;
    }

    .back-home a:hover {
        background:rgb(255, 87, 115);
    }
    form {
        display: flex;
        flex-direction: column;
        gap: 10px;
    }
    input {
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }
    button {
        padding: 10px;
        background-color: #ff758c;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }
    button:hover {
        background-color:rgb(255, 87, 115);
    }
    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }
    th, td {
        border: 1px solid #ddd;
        padding: 10px;
        text-align: center;
    }
    th {
        background-color: #ff758c;
        color: white;
    }
    .aksi a {
        text-decoration: none;
        margin: 0 5px;
        padding: 5px 10px;
        border-radius: 5px;
    }
    .edit {
        background-color:rgb(17, 0, 255);
        color: white;
    }
    .hapus {
        background-color:rgb(255, 0, 0);
        color: white;
    }
    .edit:hover {
        background-color:rgb(0, 45, 143);
    }
    .hapus:hover {
        background-color:rgb(209, 5, 5);
    }
    .modal {
        display: flex;
        align-items: center;
        justify-content: center;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.5);
    }
    .modal-content {
        background: white;
        padding: 20px;
        border-radius: 10px;
        width: 300px;
    }
    .close {
        float: right;
        cursor: pointer;
        font-size: 20px;
        font-weight: bold;
    }
</style>

</head>
<body>
    <div class="back-home">
    <a href="index.php">🏡 Kembali ke Home</a>
    </div>

    <h2>MANAJEMEN PELANGGAN</h2>

    <div class="container">
        <form method="POST">
            
            <input type="text" name="nama" placeholder="Nama Pelanggan" required>
            <input type="text" name="alamat" placeholder="Alamat" required>
            <input type="text" name="telepon" placeholder="Nomor Telepon" required>
            <button type="submit" name="tambah"><i class="fas fa-user-plus"></i> Tambah Pelanggan</button>
        </form>

        <table>
            <tr>
                <th>ID</th>
                <th>Nama</th>
                <th>Alamat</th>
                <th>Telepon</th>
                <th>Aksi</th>
            </tr>
            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <td><?= $row['PelangganID'] ?></td>
                    <td><?= $row['NamaPelanggan'] ?></td>
                    <td><?= $row['Alamat'] ?></td>
                    <td><?= $row['NomorTelepon'] ?></td>
                    <td class="aksi">
                        <a href="pelanggan.php?edit=<?= $row['PelangganID'] ?>" class="edit">
                            <i class="fas fa-edit"></i> Edit
                        </a>
                        <a href="pelanggan.php?hapus=<?= $row['PelangganID'] ?>" class="hapus" onclick="return confirm('Apakah Anda yakin ingin menghapus pelanggan ini?')">
                            <i class="fas fa-trash"></i> Hapus
                        </a>
                    </td>
                </tr>
            <?php } ?>
        </table>
    </div>

    <?php if (isset($_GET['edit'])) { ?>
    <div class="modal">
        <div class="modal-content">
            <span class="close" onclick="window.location.href='pelanggan.php'">&times;</span>
            <h3>Edit Pelanggan</h3>
            <form method="POST">
                <input type="hidden" name="id" value="<?= $edit_id ?>">
                <input type="text" name="nama" value="<?= $edit_nama ?>" required>
                <input type="text" name="alamat" value="<?= $edit_alamat ?>" required>
                <input type="text" name="telepon" value="<?= $edit_telepon ?>" required>
                <button type="submit" name="update">Update</button>
            </form>
        </div>
    </div>
    <?php } ?>
</body>
</html>