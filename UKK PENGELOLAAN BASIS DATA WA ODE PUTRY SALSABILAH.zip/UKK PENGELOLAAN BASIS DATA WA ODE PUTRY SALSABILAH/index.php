<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pengelolaan Basis Data | Wa Ode Putry Salsabilah | XII RPL B | UKK 2025</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free/js/all.min.js"></script>
    <style>
        body {
            background: linear-gradient(to right, #ff9a9e,rgb(255, 225, 217));
            color: #333;
            text-align: center;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            font-family: 'Poppins', sans-serif;
        }
        .container {
            max-width: 1111px;
            padding: 50px;
        }
        .card {
            background: #fff;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease-in-out, box-shadow 0.3s;
        }
        .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }
        .card-body {
            padding: 20px;
        }
        .btn-custom {
            background: #ff758c;
            color: white;
            padding: 10px 15px;
            border-radius: 8px;
            text-transform: uppercase;
            font-weight: bold;
            transition: background 0.3s;
            display: block;
        }
        .btn-custom:hover {
            background: #ff4f7a;
            color: white;
        }
        h1 {
            font-weight: bold;
            margin-bottom: 20px;
            color: #fff;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Pengelolaan Basis Data</h1>
        <div class="row justify-content-center">
            <div class="col-md-8 mb-3">
                <div class="card">
                    <div class="card-body">
                        <a href="pelanggan.php" class="btn btn-custom w-100">Data Pelanggan</a>
                    </div>
                </div>
            </div>
            <div class="col-md-8 mb-3">
                <div class="card">
                    <div class="card-body">
                        <a href="produk.php" class="btn btn-custom w-100">Data Produk</a>
                    </div>
                </div>
            </div>
            <div class="col-md-8 mb-3">
                <div class="card">
                    <div class="card-body">
                        <a href="penjualan.php" class="btn btn-custom w-100">Data Penjualan</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
